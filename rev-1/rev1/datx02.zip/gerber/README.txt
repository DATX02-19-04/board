File descriptions:
  rev1-B.Cu.gbr
    Bottom Copper Layer

  rev1-B.Mask.gbr
    Bottom Solder Mask

  rev1-Cmts.User.gbr
    Notes and dimensions for machining

  rev1.drl
    Drill file

  rev1-Edge.Cuts.gbr
    Board outlines and cuts

  rev1-F.Cu.gbr
    Top Copper Layer

  rev1-F.Mask.gbr
    Top Solder Mask

  rev1-F.SilkS.gbr
    Top Silk Screen

Notes:
* No bottom silk screen
* The mounting holes have a diameter of at least 4.3mm, both for the embedded
  ones as well as the ones on the milling trace.
